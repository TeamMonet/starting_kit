NOTRE DOSSIER GITHUB : 
https://github.com/TeamMonet/starting_kit


Ce projet a été fait dans le cadre d’une initiation à l’apprentissage automatique, sous la forme d’un mini-projet.
 
Il y a trois fichiers modifiés: 
-	preprocessing.py
-	model.py
-	Visualisation.py
Dans le readme.ipynb, il y a de quoi faire la gridSearch et le randomsearchCV, commentés.



L’équipe Monet est composée de : 
-	Preprocessing : Patricia & Isabelle
-	Prediction : Nasrine & Laetitia
-	Visualisation : Amel & Shuyang

L’équipe a travaillé ensemble, ce qui fait que les binômes pouvaient travailler sur d’autres parties que le leur. 
La pluralité des profils a fait que l’équipe à travaillé de manière collaborative et efficace. 
Ainsi, bien que chacun des membres était assigné à une partie, nous nous sommes entraidés pour faire ce projet. 
- Nasrine & Laetitia ont bien cerné les concepts de machine learning, ce qui a fait qu’elles ont pu vulgariser et expliquer certains aspects qui semblaient parfois abstrait à certains membres du groupe. 
- Isabelle aime débuguer. Du coup, elle a pu également participer à la partie Prédiction, comme la partie Visualisation. 
- Amel, Shuyang et Patricia ont également apporté leur contribution à tout les stades du projet. 

Enfin, nous remercions I. Guyon et Z. Liu pour leur disponibilité tout au long de ce projet. 

Pour plus d’information : http://saclay.chalearn.org/
